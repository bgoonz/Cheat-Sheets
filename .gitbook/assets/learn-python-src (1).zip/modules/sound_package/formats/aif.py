"""AIF file support."""


def aif_read():
    """AIF file reading function mock"""
    return 'Read from AIF file'
