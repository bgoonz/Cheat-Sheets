"""Echo effect."""


def echo_function():
    """Echo function mock"""
    return 'Do echo effect'
