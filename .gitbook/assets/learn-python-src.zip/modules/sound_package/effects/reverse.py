"""Reverse effect."""


def reverse_function():
    """Reveres function mock"""
    return 'Do reverse effect'
